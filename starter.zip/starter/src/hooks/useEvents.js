import { useEffect, useState } from "react";
import { useEventsContext } from "../context/EventsContext";

// Custom hook to fetch and filter events
function useEvents() {
  // Local state for all events from api
  const [allEvents, setAllEvents] = useState([]);

  // Loading state to show spinner or placeholder
  const [loading, setLoading] = useState(true);

  //  Get search term from context
  const { search } = useEventsContext();

  // Fetch events from API when component mounts
  useEffect(() => {
    async function fetchEvents() {
      try {
        // Fetch from backend server
        const res = await fetch("http://localhost:3000/events");
        const data = await res.json();

        //  Store events in local state
        setAllEvents(data);
      } catch (error) {
        console.error("Error loading events", error);
      } finally {
        // Whether success or error, hide loading spinner
        setLoading(false);
      }
    }

    fetchEvents();
  }, []);

  // Filter events based on search text
  const filtered = allEvents.filter(
    (event) =>
      event.title.toLowerCase().includes(search.toLowerCase()) || // Match title
      event.description.toLowerCase().includes(search.toLowerCase()) || // Match description
      event.categories.some(
        (cat) => cat.toLowerCase().includes(search.toLowerCase()) // Match category
      )
  );

  // Return filtered results and loading state
  return { events: filtered, loading };
}

export default useEvents;
