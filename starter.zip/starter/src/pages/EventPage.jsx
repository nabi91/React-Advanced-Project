import { useEffect, useState, useRef } from "react";
import { useParams, useNavigate } from "react-router-dom";
import {
  Box,
  Heading,
  Text,
  Image,
  Spinner,
  Flex,
  Button,
  useDisclosure,
  Avatar,
  AlertDialog,
  AlertDialogBody,
  AlertDialogFooter,
  AlertDialogHeader,
  AlertDialogContent,
  AlertDialogOverlay,
} from "@chakra-ui/react";

// Custom Components
import Header from "../components/Header";
import EventForm from "../components/EventForm";

// API Functions
import {
  fetchEvents,
  fetchUsers,
  fetchCategories,
  updateEvent,
  deleteEvent,
} from "../services/api";

// Format Date & Time
const formatDateTime = (isoString) => {
  if (!isoString) return "";
  const date = new Date(isoString);
  return date.toLocaleString("en-GB", {
    day: "2-digit",
    month: "short",
    year: "numeric",
    hour: "2-digit",
    minute: "2-digit",
  });
};

const EventPage = () => {
  // Get Event ID from URL
  const { id } = useParams();
  const navigate = useNavigate();

  // State Variables
  const [event, setEvent] = useState(null);
  const [creator, setCreator] = useState(null);
  const [categoryNames, setCategoryNames] = useState([]);
  const [loading, setLoading] = useState(true);
  const [users, setUsers] = useState([]);
  const [categories, setCategories] = useState([]);

  // Modal for Edit Form
  const {
    isOpen: isEditOpen,
    onOpen: openEdit,
    onClose: closeEdit,
  } = useDisclosure();

  // Modal for Delete Confirmation
  const {
    isOpen: isDeleteOpen,
    onOpen: openDeleteConfirm,
    onClose: closeDeleteConfirm,
  } = useDisclosure();
  const cancelRef = useRef();

  // Load Event, Users, and Categories
  useEffect(() => {
    const load = async () => {
      try {
        const events = await fetchEvents();
        const found = events.find((e) => String(e.id) === String(id));
        setEvent(found);

        const allUsers = await fetchUsers();
        setUsers(allUsers);
        setCreator(
          allUsers.find((u) => String(u.id) === String(found?.createdBy))
        );

        const allCats = await fetchCategories();
        setCategories(allCats);
        setCategoryNames(
          allCats
            .filter((c) => found?.categoryIds?.includes(parseInt(c.id)))
            .map((c) => c.name)
        );

        setLoading(false);
      } catch (err) {
        console.error("Failed to load event:", err);
        setLoading(false);
      }
    };

    load();
  }, [id]);

  // Submit Edited Data
  const handleEditSubmit = async (updatedEvent) => {
    try {
      await updateEvent(id, updatedEvent);
      setEvent({ ...event, ...updatedEvent });
      closeEdit();
    } catch (err) {
      console.error("Update failed:", err);
    }
  };

  // Handle Event Deletion
  const handleDelete = async () => {
    try {
      await deleteEvent(id);
      closeDeleteConfirm();
      navigate("/");
    } catch (error) {
      console.error("Delete failed:", error);
    }
  };

  // Loading Spinner
  if (loading) {
    return (
      <Flex justify="center" align="center" minH="300px">
        <Spinner size="xl" />
      </Flex>
    );
  }

  // No Event Found
  if (!event) {
    return (
      <Box textAlign="center" mt={10}>
        <Heading size="lg" color="red.500">
          Event not found
        </Heading>
      </Box>
    );
  }

  // Main Event Page UI
  return (
    <Box bg={{ base: "white", md: "#fcf7e1" }} minH="100vh" px={4} py={4}>
      {/* Top Header Bar */}
      <Box maxW="1600px" mx="auto" px={6} mb={4}>
        <Header />
      </Box>

      {/* Event Details Section */}
      <Box maxW="1600px" mx="auto" px={6} pb={10}>
        <Flex
          bg="white"
          borderRadius="md"
          border="1px solid #e2e8f0"
          overflow="hidden"
          p={8}
          gap={10}
          wrap="wrap"
        >
          {/* Hero section Text Info */}
          <Box flex="1" minW="300px">
            <Heading mb={2} color="#8e0002">
              {event.title}
            </Heading>

            {categoryNames.length > 0 && (
              <Text fontSize="md" mb={2}>
                <strong>Categories:</strong> {categoryNames.join(", ")}
              </Text>
            )}

            <Text fontSize="md" mb={2}>
              <strong>Location:</strong> {event.location}
            </Text>

            <Text fontSize="md" mb={2}>
              <strong>Start Time:</strong> {formatDateTime(event.startTime)}
            </Text>
            <Text fontSize="md" mb={2}>
              <strong>End Time:</strong> {formatDateTime(event.endTime)}
            </Text>

            <Text fontSize="md" mb={2}>
              <strong>Description:</strong> {event.description}
            </Text>

            {/* Creator Info */}
            {creator && (
              <Box mt={4}>
                <Text fontWeight="bold" mb={1}>
                  Created By:
                </Text>
                <Flex align="center">
                  <Avatar
                    src={creator.image}
                    name={creator.name}
                    size="sm"
                    mr={2}
                  />
                  <Text fontSize="sm" fontWeight="medium" color="gray.700">
                    {creator.name}
                  </Text>
                </Flex>
              </Box>
            )}

            {/* Action Buttons */}
            <Flex gap={3} wrap="wrap" mt={6}>
              <Button
                onClick={() => navigate("/")}
                colorScheme="gray"
                variant="outline"
              >
                ← Back
              </Button>
              <Button colorScheme="blue" onClick={openEdit}>
                Edit
              </Button>
              <Button colorScheme="red" onClick={openDeleteConfirm}>
                Delete
              </Button>
            </Flex>
          </Box>

          {/* Event Image */}
          <Box
            width="100%"
            display="flex"
            justifyContent="center"
            alignItems="center"
            px={{ base: 0, md: 0 }}
            mt={{ base: 4, md: 0 }}
          >
            <Image
              src={event.image}
              alt={event.title}
              borderRadius="md"
              objectFit="cover"
              maxW="100%"
              width={{ base: "100%", md: "100%" }}
            />
          </Box>
        </Flex>
      </Box>

      {/* Edit Modal Form */}
      {isEditOpen && (
        <EventForm
          initialData={event}
          usersList={users}
          categoriesList={categories}
          onSubmit={handleEditSubmit}
          onCancel={closeEdit}
        />
      )}

      {/* Custom Delete Confirmation Dialog */}
      <AlertDialog
        isOpen={isDeleteOpen}
        leastDestructiveRef={cancelRef}
        onClose={closeDeleteConfirm}
      >
        <AlertDialogOverlay>
          <AlertDialogContent>
            <AlertDialogHeader fontSize="lg" fontWeight="bold">
              Delete Event
            </AlertDialogHeader>

            <AlertDialogBody>
              Are you sure you want to delete this event?
            </AlertDialogBody>

            <AlertDialogFooter>
              <Button ref={cancelRef} onClick={closeDeleteConfirm}>
                Cancel
              </Button>
              <Button colorScheme="red" onClick={handleDelete} ml={3}>
                Delete
              </Button>
            </AlertDialogFooter>
          </AlertDialogContent>
        </AlertDialogOverlay>
      </AlertDialog>
    </Box>
  );
};

export default EventPage;
