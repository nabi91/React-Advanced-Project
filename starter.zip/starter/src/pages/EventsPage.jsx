import { useEffect, useMemo, useState } from "react";
import {
  Box,
  Flex,
  Heading,
  Text,
  Image,
  useDisclosure,
  useToast,
  Modal,
  ModalOverlay,
  ModalContent,
  ModalHeader,
  ModalCloseButton,
  ModalBody,
  ModalFooter,
  Button,
} from "@chakra-ui/react";

import Header from "../components/Header";
import EventGrid from "../components/EventGrid";
import EventForm from "../components/EventForm";

// API service functions
import {
  fetchEvents,
  fetchUsers,
  fetchCategories,
  createEvent,
  updateEvent,
  deleteEvent,
} from "../services/api";

// EventsPage Component
const EventsPage = () => {
  // State variables
  const [searchTerm, setSearchTerm] = useState("");
  const [events, setEvents] = useState([]);
  const [users, setUsers] = useState([]);
  const [categories, setCategories] = useState([]);
  const [selectedEvent, setSelectedEvent] = useState(null);
  const [viewingEvent, setViewingEvent] = useState(null);

  // Modal control
  const { isOpen, onOpen, onClose } = useDisclosure();

  // Toast for success/error messages
  const toast = useToast();

  // Load events on mount
  useEffect(() => {
    fetchEvents()
      .then((newEvents) => {
        const sorted = newEvents.sort(
          (a, b) => parseInt(b.id) - parseInt(a.id)
        );
        setEvents(sorted);
      })
      .catch((err) => console.error("Error loading events:", err));
  }, []);

  // Load users on mount
  useEffect(() => {
    fetchUsers()
      .then(setUsers)
      .catch((err) => console.error("Error loading users:", err));
  }, []);

  // Load categories on mount
  useEffect(() => {
    fetchCategories()
      .then(setCategories)
      .catch((err) => console.error("Error loading categories:", err));
  }, []);

  // Get random event image
  const randomImage = useMemo(() => {
    if (events.length === 0) return null;
    const imageList = events.map((e) => e.image).filter(Boolean);
    return imageList[Math.floor(Math.random() * imageList.length)];
  }, [events]);

  // Open Add Event modal
  const handleOpenAdd = () => {
    setSelectedEvent(null);
    onOpen();
  };

  // Open Edit Event modal
  const handleEditEvent = (event) => {
    setSelectedEvent(event);
    onOpen();
  };

  // Delete an event
  const handleDeleteEvent = (id) => {
    deleteEvent(id)
      .then(() => {
        setEvents((prev) => prev.filter((e) => e.id !== id));
        toast({ title: "Event deleted", status: "info", duration: 3000 });
      })
      .catch((err) => {
        console.error(err);
        toast({ title: "Error deleting event", status: "error" });
      });
  };

  // Save event
  const handleSaveEvent = (data) => {
    const isEdit = !!data.id;

    const formattedEvent = {
      id: isEdit
        ? data.id
        : String(
            Math.max(0, ...events.map((e) => parseInt(e.id, 10) || 0)) + 1
          ),
      createdBy: parseInt(data.creatorId),
      title: data.title,
      description: data.description,
      image: data.image,
      categoryIds: data.categories.map((id) => parseInt(id)),
      location: data.location,
      startTime: data.startTime,
      endTime: data.endTime,
    };

    const saveAction = isEdit
      ? updateEvent(formattedEvent.id, formattedEvent)
      : createEvent(formattedEvent);

    saveAction
      .then((savedEvent) => {
        setEvents((prev) =>
          isEdit
            ? prev.map((event) =>
                event.id === savedEvent.id ? savedEvent : event
              )
            : [savedEvent, ...prev]
        );
        onClose();
        setSelectedEvent(null);
        toast({
          title: isEdit ? "Event updated!" : "Event created!",
          status: "success",
          duration: 3000,
        });
      })
      .catch((err) => {
        console.error(err);
        toast({ title: "Error saving event", status: "error", duration: 3000 });
      });
  };

  // Get category names by ids
  const getCategoryNames = (ids) => {
    return categories
      .filter((c) => ids.includes(parseInt(c.id)))
      .map((c) => c.name);
  };

  // Get user name by id
  const getUserName = (id) => {
    const user = users.find((u) => u.id === id);
    return user ? user.name : "Unknown";
  };

  return (
    <Box
      bg={{ base: "white", md: "#fcf7e1" }}
      minH="100vh"
      px={{ base: 0, md: 4 }}
      py={4}
    >
      {/* Header Section */}
      <Box maxW="1600px" mx="auto" px={6} mb={4}>
        <Header onSearch={setSearchTerm} onAddClick={handleOpenAdd} />
      </Box>

      {/* Intro Banner Section */}
      <Box maxW="1600px" mx="auto" px={{ base: 4, md: 6 }} py={10} pt={0}>
        <Flex
          direction={{ base: "column", md: "row" }}
          align="center"
          justify="space-between"
          gap={8}
          bg="#ffffff"
          p={{ base: 0, md: 6 }}
          borderRadius="md"
        >
          {/* Text Description */}
          <Box
            flex="1"
            minW="300px"
            textAlign={{ base: "center", md: "left" }}
            p={8}
          >
            <Heading fontSize={{ base: "md", md: "xl" }} textAlign="center">
              Where Great Moments Begin
            </Heading>

            <Heading
              fontSize={{ base: "2xl", md: "5xl" }} // smaller sreen
              m={6}
              color="#8e0002"
              textShadow="1px 1px gray"
              textAlign="center"
            >
              Events Made Easy
            </Heading>

            <Text fontSize="md" color="gray.700" textAlign="center">
              From small meetups to big festivals, everything you need to
              organize or attend an event is here. Simplify planning and amplify
              participation.
            </Text>
          </Box>

          {/* Random Event Image */}
          <Box
            flex="1"
            minW="250px"
            maxW="600px"
            mx="auto"
            textAlign="center"
            display={{ base: "none", md: "block" }}
            boxShadow="xl"
          >
            <Box
              w="100%"
              h="300px"
              overflow="hidden"
              border="1px solid #ccc"
              borderRadius="md"
            >
              {randomImage && (
                <Image
                  src={randomImage}
                  alt="Event preview"
                  objectFit="cover"
                  width="100%"
                  height="100%"
                />
              )}
            </Box>
          </Box>
        </Flex>
      </Box>

      {/* Event Grid Section */}
      <Box maxW="1600px" mx="auto">
        <EventGrid
          search={searchTerm}
          events={events}
          users={users}
          categories={categories}
          onEdit={handleEditEvent}
          onDelete={handleDeleteEvent}
          onView={setViewingEvent}
        />
      </Box>

      {/* Modal: Add / Edit Form */}
      {isOpen && (selectedEvent || selectedEvent === null) && (
        <EventForm
          key={selectedEvent?.id || "new"}
          initialData={selectedEvent}
          onSubmit={handleSaveEvent}
          onCancel={() => {
            onClose();
            setSelectedEvent(null);
          }}
          usersList={users}
          categoriesList={categories}
        />
      )}

      {/* Modal: View Event Details */}
      {viewingEvent && (
        <Modal isOpen={!!viewingEvent} onClose={() => setViewingEvent(null)}>
          <ModalOverlay />
          <ModalContent>
            <ModalHeader>{viewingEvent.title}</ModalHeader>
            <ModalCloseButton />
            <ModalBody>
              <Text>
                <strong>Categories:</strong>{" "}
                {getCategoryNames(viewingEvent.categoryIds).join(", ")}
              </Text>
              <Text>
                <strong>Location:</strong> {viewingEvent.location}
              </Text>
              <Text>
                <strong>Start:</strong> {viewingEvent.startTime}
              </Text>
              <Text>
                <strong>End:</strong> {viewingEvent.endTime}
              </Text>
              <Text>
                <strong>Description:</strong> {viewingEvent.description}
              </Text>
              <Text>
                <strong>Created By:</strong>{" "}
                {getUserName(viewingEvent.createdBy)}
              </Text>
              <Image
                mt={4}
                src={viewingEvent.image}
                alt={viewingEvent.title}
                width="100%"
              />
            </ModalBody>
            <ModalFooter>
              <Button onClick={() => setViewingEvent(null)}>Close</Button>
            </ModalFooter>
          </ModalContent>
        </Modal>
      )}
    </Box>
  );
};

export default EventsPage;
