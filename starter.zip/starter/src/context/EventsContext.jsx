import { createContext, useContext, useEffect, useState } from "react";

// to store events and search state
const EventsContext = createContext();

// Context Provider Component
export function EventsProvider({ children }) {
  // State: list of events
  const [events, setEvents] = useState([]);

  // State: search text
  const [search, setSearch] = useState("");

  // Fetch events data when component mounts
  useEffect(() => {
    const fetchEvents = async () => {
      try {
        const res = await fetch("/events.json");
        const data = await res.json();

        setEvents(data); // Store the events data in state
      } catch (error) {
        console.error("Error loading events:", error);
        setEvents([]); // Fallback: set to empty array on error
      }
    };

    fetchEvents();
  }, []);

  // Provide state and setter to chiildren components
  return (
    <EventsContext.Provider value={{ events, search, setSearch }}>
      {children}
    </EventsContext.Provider>
  );
}

// Custom hook to access the context easily
export function useEventsContext() {
  return useContext(EventsContext);
}
