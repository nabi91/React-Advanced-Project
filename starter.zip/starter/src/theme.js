import { extendTheme } from "@chakra-ui/react";

const theme = extendTheme({
  styles: {
    global: {
      body: {
        bg: "#fcf7e1",
        margin: 0,
        padding: 0,
      },
    },
  },
});

export default theme;
