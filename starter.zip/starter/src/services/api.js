const BASE_URL = "http://localhost:3000";

// Fetch all events
export const fetchEvents = async () => {
  const res = await fetch(`${BASE_URL}/events`);
  if (!res.ok) throw new Error("Failed to fetch events");
  return await res.json();
};

// Fetch all users
export const fetchUsers = async () => {
  const res = await fetch(`${BASE_URL}/users`);
  if (!res.ok) throw new Error("Failed to fetch users");
  return await res.json();
};

// Fetch all categories
export const fetchCategories = async () => {
  const res = await fetch(`${BASE_URL}/categories`);
  if (!res.ok) throw new Error("Failed to fetch categories");
  return await res.json();
};

// Create a new event
export const createEvent = async (eventData) => {
  const res = await fetch(`${BASE_URL}/events`, {
    method: "POST",
    headers: {
      "Content-Type": "application/json",
    },
    body: JSON.stringify(eventData),
  });
  if (!res.ok) throw new Error("Failed to create event");
  return await res.json();
};

// Save updated categories list
export const updateCategories = async (newCategories) => {
  // Overwrites the whole categories array
  const promises = newCategories.map(async (category) => {
    const res = await fetch(`${BASE_URL}/categories/${category.id}`, {
      method: "PUT",
      headers: {
        "Content-Type": "application/json",
      },
      body: JSON.stringify(category),
    });

    // If not exists, create it
    if (res.status === 404) {
      const createRes = await fetch(`${BASE_URL}/categories`, {
        method: "POST",
        headers: {
          "Content-Type": "application/json",
        },
        body: JSON.stringify(category),
      });
      if (!createRes.ok) throw new Error("Failed to create category");
      return await createRes.json();
    }

    if (!res.ok) throw new Error("Failed to update category");
    return await res.json();
  });

  return Promise.all(promises);
};

// Update an existing event
export const updateEvent = async (id, updatedEventData) => {
  const res = await fetch(`${BASE_URL}/events/${id}`, {
    method: "PATCH",
    headers: {
      "Content-Type": "application/json",
    },
    body: JSON.stringify(updatedEventData),
  });
  if (!res.ok) throw new Error("Failed to update event");
  return await res.json();
};

// Delete an event by ID
export const deleteEvent = async (id) => {
  const res = await fetch(`${BASE_URL}/events/${id}`, {
    method: "DELETE",
  });
  if (!res.ok) throw new Error("Failed to delete event");
  return true;
};
