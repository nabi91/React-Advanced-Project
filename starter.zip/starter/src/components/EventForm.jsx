import React, { useState, useEffect } from "react";
import {
  Modal,
  ModalOverlay,
  ModalContent,
  ModalHeader,
  ModalCloseButton,
  ModalBody,
  ModalFooter,
  Button,
  Input,
  Textarea,
  Select,
  Box,
  FormControl,
  FormLabel,
  FormErrorMessage,
  Flex,
} from "@chakra-ui/react";

// EventForm component: used for adding/editing events
function EventForm({
  initialData = {},
  onSubmit,
  onCancel,
  usersList = [],
  categoriesList = [],
}) {
  // Local state to manage form data
  const [formData, setFormData] = useState({
    id: "",
    createdBy: "",
    title: "",
    description: "",
    image: "",
    location: "",
    startTime: new Date().toISOString().slice(0, 16),
    endTime: "",
    creatorId: "",
    categories: [],
  });

  // Error state for form validation
  const [errors, setErrors] = useState({});

  // Pre-fill form fields when editing an event
  useEffect(() => {
    if (initialData) {
      setFormData({
        id: initialData.id || "",
        createdBy: initialData.createdBy || "",
        title: initialData.title || "",
        description: initialData.description || "",
        image: initialData.image || "",
        location: initialData.location || "",
        startTime:
          initialData.startTime || new Date().toISOString().slice(0, 16),
        endTime: initialData.endTime || "",
        creatorId: initialData.creatorId || initialData.createdBy || "",
        categories:
          initialData.categories || initialData.categoryIds?.map(String) || [],
      });
    }
  }, [initialData]);

  // Handle text input changes
  const handleInputChange = (e) => {
    const { name, value } = e.target;
    setFormData((prev) => ({ ...prev, [name]: value }));
  };

  // Handle category dropdown change
  const handleCategoryChange = (e) => {
    const selected = parseInt(e.target.value, 10);
    setFormData((prev) => ({ ...prev, categories: [selected] }));
  };

  // Validate required fields before submit
  const validate = () => {
    const newErrors = {};
    if (!formData.title) newErrors.title = "Title is required";
    if (!formData.description)
      newErrors.description = "Description is required";
    if (!formData.image) newErrors.image = "Image URL is required";
    if (!formData.location) newErrors.location = "Location is required";
    if (!formData.startTime) newErrors.startTime = "Start time is required";
    if (!formData.endTime) newErrors.endTime = "End time is required";
    if (!formData.creatorId) newErrors.creatorId = "Creator is required";
    if (!formData.categories.length)
      newErrors.categories = "Category is required";
    setErrors(newErrors);
    return Object.keys(newErrors).length === 0;
  };

  // Submit form if valid
  const handleSubmit = () => {
    if (!validate()) return;
    onSubmit(formData);
  };

  return (
    // Modal Wrapper
    <Modal isOpen onClose={onCancel} size="xl">
      <ModalOverlay />
      <ModalContent>
        {/* Header with optional close button */}
        <ModalHeader>{formData.id ? "Edit Event" : "Add Event"}</ModalHeader>
        <ModalCloseButton color="#8e0002" />

        {/* Form Fields */}
        <ModalBody>
          <Box
            bg="gray.50"
            p={5}
            borderRadius="md"
            boxShadow="sm"
            border="1px solid #e2e8f0"
          >
            {/* Title Field */}
            <FormControl mb={4} isInvalid={!!errors.title} isRequired>
              <FormLabel fontWeight="semibold">Title</FormLabel>
              <Input
                name="title"
                value={formData.title}
                onChange={handleInputChange}
              />
              <FormErrorMessage>{errors.title}</FormErrorMessage>
            </FormControl>

            {/* Description Field */}
            <FormControl mb={4} isInvalid={!!errors.description} isRequired>
              <FormLabel fontWeight="semibold">Description</FormLabel>
              <Textarea
                name="description"
                value={formData.description}
                onChange={handleInputChange}
              />
              <FormErrorMessage>{errors.description}</FormErrorMessage>
            </FormControl>

            {/* Image Field */}
            <FormControl mb={4} isInvalid={!!errors.image} isRequired>
              <FormLabel fontWeight="semibold">Image URL</FormLabel>
              <Input
                name="image"
                value={formData.image}
                onChange={handleInputChange}
              />
              <FormErrorMessage>{errors.image}</FormErrorMessage>
            </FormControl>

            {/* Location Field */}
            <FormControl mb={4} isInvalid={!!errors.location} isRequired>
              <FormLabel fontWeight="semibold">Location</FormLabel>
              <Input
                name="location"
                value={formData.location}
                onChange={handleInputChange}
              />
              <FormErrorMessage>{errors.location}</FormErrorMessage>
            </FormControl>

            {/* Date-Time Fields (Start & End Time) */}
            <Flex direction={{ base: "column", md: "row" }} gap={4}>
              <FormControl
                flex="1"
                mb={4}
                isInvalid={!!errors.startTime}
                isRequired
              >
                <FormLabel fontWeight="semibold">Start Time</FormLabel>
                <Input
                  type="datetime-local"
                  name="startTime"
                  value={formData.startTime}
                  onChange={handleInputChange}
                  fontSize="sm"
                  padding="2"
                  rounded="md"
                  bg="white"
                  borderColor="gray.300"
                  _focus={{
                    borderColor: "#8e0002",
                    boxShadow: "0 0 0 1px #8e0002",
                  }}
                  color="gray.700"
                />
                <FormErrorMessage>{errors.startTime}</FormErrorMessage>
              </FormControl>

              <FormControl
                flex="1"
                mb={4}
                isInvalid={!!errors.endTime}
                isRequired
              >
                <FormLabel fontWeight="semibold">End Time</FormLabel>
                <Input
                  type="datetime-local"
                  name="endTime"
                  value={formData.endTime}
                  onChange={handleInputChange}
                  fontSize="sm"
                  padding="2"
                  rounded="md"
                  bg="white"
                  borderColor="gray.300"
                  _focus={{
                    borderColor: "#8e0002",
                    boxShadow: "0 0 0 1px #8e0002",
                  }}
                  color="gray.700"
                />
                <FormErrorMessage>{errors.endTime}</FormErrorMessage>
              </FormControl>
            </Flex>

            {/* Creator Dropdown */}
            <FormControl mb={4} isInvalid={!!errors.creatorId} isRequired>
              <FormLabel fontWeight="semibold">Creator</FormLabel>
              <Select
                placeholder="Select creator"
                name="creatorId"
                value={formData.creatorId}
                onChange={handleInputChange}
              >
                {usersList.map((user) => (
                  <option key={user.id} value={user.id}>
                    {user.name}
                  </option>
                ))}
              </Select>
              <FormErrorMessage>{errors.creatorId}</FormErrorMessage>
            </FormControl>

            {/* Category Dropdown */}
            <FormControl isInvalid={!!errors.categories} isRequired>
              <FormLabel fontWeight="semibold">Category</FormLabel>
              <Select
                placeholder="Select category"
                name="categories"
                value={formData.categories[0] || ""}
                onChange={handleCategoryChange}
              >
                {categoriesList.map((cat) => (
                  <option key={cat.id} value={cat.id}>
                    {cat.name}
                  </option>
                ))}
              </Select>
              <FormErrorMessage>{errors.categories}</FormErrorMessage>
            </FormControl>
          </Box>
        </ModalBody>

        {/* Footer Buttons */}
        <ModalFooter>
          <Button
            bg="#8e0002"
            color="white"
            _hover={{ bg: "#6e0000" }}
            onClick={handleSubmit}
            mr={3}
          >
            Save
          </Button>
          <Button onClick={onCancel}>Cancel</Button>
        </ModalFooter>
      </ModalContent>
    </Modal>
  );
}

export default EventForm;
