import {
  Box,
  Flex,
  Heading,
  Input,
  Button,
  IconButton,
  Image,
  useBreakpointValue,
  Menu,
  MenuButton,
  MenuList,
} from "@chakra-ui/react";
import { AddIcon, HamburgerIcon } from "@chakra-ui/icons";
import { useState } from "react";
import logo from "../assets/logo.svg";

// Header Component
const Header = ({ onSearch, onAddClick }) => {
  // search input value
  const [searchValue, setSearchValue] = useState("");

  // Check if screen is small size
  const isMobile = useBreakpointValue({ base: true, md: false });

  return (
    //  Header
    <Box bg="#8e0002" py={4} px={{ base: 2, md: 6 }}>
      {/* Flexbox layout for header content */}
      <Flex justify="space-between" align="center" wrap="wrap" gap={4}>
        {/* Logo Section - takes user to home page (with reload) */}
        <Box
          flex="1"
          textAlign={{ base: "center", md: "left" }}
          display="flex"
          justifyContent={{ base: "center", md: "flex-start" }}
        >
          <Flex
            justify="center"
            align="center"
            gap={2}
            cursor="pointer"
            onClick={() => (window.location.href = "/")}
          >
            <Image
              src={logo}
              alt="Logo"
              boxSize={{ base: "32px", md: "40px" }}
              filter="brightness(0) invert(1)"
            />
            <Heading
              size={{ base: "lg", md: "xl" }}
              color="white"
              letterSpacing="0.5em"
              noOfLines={1}
            >
              EVENTS
            </Heading>
          </Flex>
        </Box>

        {/* Hamburger menu (for small screen view) */}
        {isMobile ? (
          <Menu>
            <MenuButton
              as={IconButton}
              icon={<HamburgerIcon />}
              variant="ghost"
              color="white"
              aria-label="Menu"
              _hover={{ bg: "transparent" }}
              _active={{ bg: "transparent" }}
              size="lg"
            />
            <MenuList px={3} py={2}>
              {/* Search input (for small screen) */}
              <Input
                placeholder="Search…"
                size="sm"
                bg="white"
                mb={2}
                value={searchValue}
                onChange={(e) => {
                  setSearchValue(e.target.value);
                  onSearch(e.target.value);
                }}
              />
              {/* Add event button (for small screen) */}
              <Button
                size="sm"
                w="100%"
                onClick={onAddClick}
                leftIcon={<AddIcon />}
                bg="#facc15"
                color="black"
                _hover={{ bg: "#fbbf24" }}
              >
                Add Event
              </Button>
            </MenuList>
          </Menu>
        ) : (
          // Desktop: Search and Add button side by side
          <Flex gap={2} align="center">
            {/* Search input (desktop) */}
            <Input
              placeholder="Search by title, category or users"
              onChange={(e) => onSearch(e.target.value)}
              bg="white"
              color="black"
              size="sm"
              w="250px"
              border="1px solid #ccc"
              borderRadius="md"
            />
            {/* Add event button (desktop) */}
            <Button
              size="sm"
              px={6}
              onClick={onAddClick}
              borderRadius="md"
              bg="#facc15"
              color="black"
              _hover={{ bg: "#fbbf24" }}
            >
              Add Event
            </Button>
          </Flex>
        )}
      </Flex>
    </Box>
  );
};

export default Header;
