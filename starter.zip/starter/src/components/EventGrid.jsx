import { Box, SimpleGrid } from "@chakra-ui/react";
import EventCard from "./EventCard";

//  EventGrid component: displays a grid of filtered event cards
const EventGrid = ({
  search = "",
  events = [],
  users = [],
  categories = [],
  onEdit = () => {},
  onDelete = () => {},
  onView = () => {},
}) => {
  //  Normalize search string to lowercase
  const searchLower = search.toLowerCase().trim();

  //  Filter events based on title, creator, or category
  const filteredEvents = events.filter((event) => {
    // Match event title
    const matchTitle = event.title.toLowerCase().includes(searchLower);

    // Match creator name
    const user = users.find((u) => String(u.id) === String(event.createdBy));
    const matchUser = user?.name?.toLowerCase().includes(searchLower);

    // Match category name
    const matchCategory = event.categoryIds?.some((catId) => {
      const category = categories.find((c) => String(c.id) === String(catId));
      return category?.name?.toLowerCase().includes(searchLower);
    });

    // Return true if any match
    return matchTitle || matchUser || matchCategory;
  });

  return (
    <Box px={6} pb={10}>
      {/* Responsive grid layout for event cards */}
      <SimpleGrid
        columns={2}
        spacing={6}
        minChildWidth="230px"
        maxW="100%"
        justifyContent="center"
      >
        {filteredEvents.map((event) => (
          <Box key={event.id} maxW="300px" minW="230px" w="100%" mx="auto">
            {/* Render each event using EventCard component */}
            <EventCard
              event={event}
              users={users}
              categories={categories}
              onEdit={() => onEdit(event)}
              onDelete={() => onDelete(event.id)}
              onView={() => onView(event)}
            />
          </Box>
        ))}
      </SimpleGrid>
    </Box>
  );
};

export default EventGrid;
