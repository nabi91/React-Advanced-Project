import { Box, Heading, Text, Image, Flex, Avatar } from "@chakra-ui/react";
import { Link } from "react-router-dom";

//  Format date and time from ISO string to readable format
const formatDateTime = (isoString) => {
  if (!isoString) return "";
  const date = new Date(isoString);
  return date.toLocaleString("en-GB", {
    day: "2-digit",
    month: "short",
    year: "numeric",
    hour: "2-digit",
    minute: "2-digit",
  });
};

//  Main EventCard Component
const EventCard = ({ event, users = [], categories = [] }) => {
  //  Destructure required fields from the event
  const { id, title, image, startTime, endTime, createdBy, categoryIds } =
    event;

  // Find creator info by matching createdBy
  const creator = users.find((user) => String(user.id) === String(createdBy));

  // Find the first category (if available)
  const category =
    Array.isArray(categoryIds) && categoryIds.length > 0
      ? categories.find((cat) => String(cat.id) === String(categoryIds[0]))
      : null;

  return (
    // Wrap the entire card with a link to the event detail page
    <Link to={`/event/${id}`} style={{ textDecoration: "none" }}>
      {/* Card Container */}
      <Box
        bg="white"
        borderRadius="md"
        boxShadow="lg"
        overflow="hidden"
        transition="transform 0.2s"
        _hover={{ transform: "scale(1.02)", boxShadow: "xl" }}
      >
        <Flex
          direction={{ base: "row-reverse", md: "column" }}
          align="stretch"
          wrap="nowrap"
          h={{ base: "200px", md: "auto" }}
        >
          {image && (
            <Image
              src={image}
              alt={title}
              w={{ base: "40%", md: "100%" }}
              h={{ base: "100%", md: "200px" }}
              objectFit="cover"
            />
          )}

          {/* Card Content */}
          <Box p={4} minW="0" w={{ base: "60%", md: "100%" }}>
            {/*  Card Title  */}
            <Heading
              size="sm"
              mb={1}
              color="#8e0002"
              textShadow="1px 1px 2px rgba(0, 0, 0, 0.2)"
            >
              {title}
            </Heading>

            {/* Category Info */}
            {category && (
              <Text fontSize="xs" color="gray.500" mb={2}>
                Category: {category.name}
              </Text>
            )}

            {/* Date and Time Info */}
            <Box mb={3}>
              <Text fontSize="sm" color="gray.600">
                Start: {formatDateTime(startTime)}
              </Text>
              <Text fontSize="sm" color="gray.600">
                End: {formatDateTime(endTime)}
              </Text>
            </Box>

            {/*  Creator Info */}
            {creator && (
              <Flex align="center" mt={2}>
                <Avatar
                  src={creator.image}
                  name={creator.name}
                  size="sm"
                  mr={2}
                />
                <Text fontSize="sm" color="gray.700" fontWeight="medium">
                  {creator.name}
                </Text>
              </Flex>
            )}
          </Box>
        </Flex>
      </Box>
    </Link>
  );
};

export default EventCard;
